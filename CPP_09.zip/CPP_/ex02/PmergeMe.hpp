#ifndef PMERGEME_HPP
# define PMERGEME_HPP

# include <vector>
# include <deque>
# include <string>
# include <utility>

/*
 * PmergeMe
 * ---------
 * Implements the Ford-Johnson "merge-insertion" sort for TWO different
 * standard containers:
 *   - std::vector<int>
 *   - std::deque<int>
 *
 * We measure and print the total time spent sorting for each container
 * so you can compare them.
 *
 * The subject insists on writing the algorithm independently for each
 * container (no generic function). We respect that.
 */
class PmergeMe
{
	private:
		std::vector<int>	_vec;
		std::deque<int>		_deq;

		/* ---------- vector version ---------- */
		void	_sortVector(std::vector<int>& v);
		void	_insertVec(std::vector<int>& main, int value);

		/* ---------- deque  version ---------- */
		void	_sortDeque(std::deque<int>& d);
		void	_insertDeq(std::deque<int>& main, int value);

		/* ---------- helpers ---------- */
		static std::vector<size_t>	_jacobsthal(size_t upTo);

	public:
		// Orthodox Canonical Form
		PmergeMe();
		PmergeMe(const PmergeMe& other);
		PmergeMe& operator=(const PmergeMe& other);
		~PmergeMe();

		// Parse argv, fill both containers, validate
		void	parse(int argc, char** argv);

		// Sort each container, timing the whole process, and print a report
		void	run();
};

#endif
