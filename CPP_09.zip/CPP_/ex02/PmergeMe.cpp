#include "PmergeMe.hpp"

#include <iostream>
#include <sstream>
#include <cstdlib>
#include <cctype>
#include <stdexcept>
#include <limits>
#include <ctime>
#include <iomanip>

/* =======================================================================
 *  Orthodox Canonical Form
 * ======================================================================= */

PmergeMe::PmergeMe() {}

PmergeMe::PmergeMe(const PmergeMe& other)
	: _vec(other._vec), _deq(other._deq) {}

PmergeMe& PmergeMe::operator=(const PmergeMe& other)
{
	if (this != &other)
	{
		_vec = other._vec;
		_deq = other._deq;
	}
	return *this;
}

PmergeMe::~PmergeMe() {}

/* =======================================================================
 *  Input parsing
 * ======================================================================= */

void	PmergeMe::parse(int argc, char** argv)
{
	if (argc < 2)
		throw std::runtime_error("Error");

	for (int i = 1; i < argc; ++i)
	{
		std::string s(argv[i]);
		if (s.empty())
			throw std::runtime_error("Error");
		for (size_t k = 0; k < s.size(); ++k)
			if (!std::isdigit(static_cast<unsigned char>(s[k])))
				throw std::runtime_error("Error");

		char*	endp = 0;
		long	n = std::strtol(s.c_str(), &endp, 10);
		if (*endp != '\0' || n < 0 || n > std::numeric_limits<int>::max())
			throw std::runtime_error("Error");

		_vec.push_back(static_cast<int>(n));
		_deq.push_back(static_cast<int>(n));
	}
}

/* =======================================================================
 *  Jacobsthal sequence helper
 *  J(0)=0, J(1)=1, J(n)=J(n-1)+2*J(n-2) -> 0,1,1,3,5,11,21,43,85,...
 *  We generate up to and including the first value >= upTo.
 * ======================================================================= */

std::vector<size_t>	PmergeMe::_jacobsthal(size_t upTo)
{
	std::vector<size_t> j;
	j.push_back(0);
	j.push_back(1);
	while (j.back() < upTo)
	{
		size_t next = j[j.size() - 1] + 2 * j[j.size() - 2];
		j.push_back(next);
	}
	return j;
}

/* =======================================================================
 *  VECTOR version
 * ======================================================================= */

void	PmergeMe::_insertVec(std::vector<int>& main, int value)
{
	// Binary search for upper bound (<=) -> insertion point.
	size_t	lo = 0;
	size_t	hi = main.size();
	while (lo < hi)
	{
		size_t mid = (lo + hi) / 2;
		if (main[mid] <= value)
			lo = mid + 1;
		else
			hi = mid;
	}
	main.insert(main.begin() + lo, value);
}

void	PmergeMe::_sortVector(std::vector<int>& v)
{
	if (v.size() < 2)
		return;

	/* 1. Split off an odd "straggler" if n is odd. */
	bool	hasStraggler = (v.size() % 2 == 1);
	int		straggler = 0;
	if (hasStraggler)
	{
		straggler = v.back();
		v.pop_back();
	}

	/* 2. Build pairs (larger, smaller). */
	std::vector<std::pair<int, int> > pairs;
	pairs.reserve(v.size() / 2);
	for (size_t i = 0; i < v.size(); i += 2)
	{
		if (v[i] > v[i + 1])
			pairs.push_back(std::make_pair(v[i],     v[i + 1]));
		else
			pairs.push_back(std::make_pair(v[i + 1], v[i]));
	}

	/* 3. Sort pairs by their larger element (binary-insertion sort).
	 *    This is the "recursive" merge-insertion step, flattened. */
	for (size_t i = 1; i < pairs.size(); ++i)
	{
		std::pair<int, int> key = pairs[i];
		size_t lo = 0, hi = i;
		while (lo < hi)
		{
			size_t mid = (lo + hi) / 2;
			if (pairs[mid].first < key.first)
				lo = mid + 1;
			else
				hi = mid;
		}
		for (size_t k = i; k > lo; --k)
			pairs[k] = pairs[k - 1];
		pairs[lo] = key;
	}

	/* 4. Main chain = all larger values in sorted order.
	 *    Prepend the first pair's smaller value (guaranteed smallest). */
	std::vector<int> main;
	main.reserve(pairs.size() * 2 + 1);
	main.push_back(pairs[0].second);
	for (size_t i = 0; i < pairs.size(); ++i)
		main.push_back(pairs[i].first);

	/* 5. Pending = smaller values of pairs 2..n (b2, b3, ...). */
	std::vector<int> pend;
	pend.reserve(pairs.size());
	for (size_t i = 1; i < pairs.size(); ++i)
		pend.push_back(pairs[i].second);

	/* 6. Insert pending values into main in Jacobsthal order.
	 *    Order is: b3, b2, then b5, b4, then b11..b6, ... */
	if (!pend.empty())
	{
		std::vector<size_t>	jac = _jacobsthal(pend.size());
		std::vector<bool>	done(pend.size(), false);

		for (size_t k = 2; k < jac.size(); ++k)
		{
			size_t hi = jac[k];
			size_t lo = jac[k - 1];
			if (hi > pend.size())
				hi = pend.size();
			for (size_t i = hi; i > lo; --i)
			{
				size_t idx = i - 1;
				if (idx >= pend.size() || done[idx])
					continue;
				_insertVec(main, pend[idx]);
				done[idx] = true;
			}
		}
		/* Sweep anything the Jacobsthal walk missed (safety net). */
		for (size_t i = 0; i < pend.size(); ++i)
			if (!done[i])
				_insertVec(main, pend[i]);
	}

	/* 7. Insert the straggler. */
	if (hasStraggler)
		_insertVec(main, straggler);

	v = main;
}

/* =======================================================================
 *  DEQUE version (same algorithm, independently written as the subject asks)
 * ======================================================================= */

void	PmergeMe::_insertDeq(std::deque<int>& main, int value)
{
	size_t	lo = 0;
	size_t	hi = main.size();
	while (lo < hi)
	{
		size_t mid = (lo + hi) / 2;
		if (main[mid] <= value)
			lo = mid + 1;
		else
			hi = mid;
	}
	main.insert(main.begin() + lo, value);
}

void	PmergeMe::_sortDeque(std::deque<int>& d)
{
	if (d.size() < 2)
		return;

	bool	hasStraggler = (d.size() % 2 == 1);
	int		straggler = 0;
	if (hasStraggler)
	{
		straggler = d.back();
		d.pop_back();
	}

	std::deque<std::pair<int, int> > pairs;
	for (size_t i = 0; i < d.size(); i += 2)
	{
		if (d[i] > d[i + 1])
			pairs.push_back(std::make_pair(d[i],     d[i + 1]));
		else
			pairs.push_back(std::make_pair(d[i + 1], d[i]));
	}

	for (size_t i = 1; i < pairs.size(); ++i)
	{
		std::pair<int, int> key = pairs[i];
		size_t lo = 0, hi = i;
		while (lo < hi)
		{
			size_t mid = (lo + hi) / 2;
			if (pairs[mid].first < key.first)
				lo = mid + 1;
			else
				hi = mid;
		}
		for (size_t k = i; k > lo; --k)
			pairs[k] = pairs[k - 1];
		pairs[lo] = key;
	}

	std::deque<int> main;
	main.push_back(pairs[0].second);
	for (size_t i = 0; i < pairs.size(); ++i)
		main.push_back(pairs[i].first);

	std::deque<int> pend;
	for (size_t i = 1; i < pairs.size(); ++i)
		pend.push_back(pairs[i].second);

	if (!pend.empty())
	{
		std::vector<size_t>	jac = _jacobsthal(pend.size());
		std::deque<bool>	done(pend.size(), false);

		for (size_t k = 2; k < jac.size(); ++k)
		{
			size_t hi = jac[k];
			size_t lo = jac[k - 1];
			if (hi > pend.size())
				hi = pend.size();
			for (size_t i = hi; i > lo; --i)
			{
				size_t idx = i - 1;
				if (idx >= pend.size() || done[idx])
					continue;
				_insertDeq(main, pend[idx]);
				done[idx] = true;
			}
		}
		for (size_t i = 0; i < pend.size(); ++i)
			if (!done[i])
				_insertDeq(main, pend[i]);
	}

	if (hasStraggler)
		_insertDeq(main, straggler);

	d = main;
}

/* =======================================================================
 *  Public run: time & report
 * ======================================================================= */

static void	printSequenceVec(const char* tag, const std::vector<int>& v)
{
	std::cout << tag;
	for (size_t i = 0; i < v.size(); ++i)
		std::cout << " " << v[i];
	std::cout << std::endl;
}

void	PmergeMe::run()
{
	printSequenceVec("Before:", _vec);

	std::clock_t	t0 = std::clock();
	_sortVector(_vec);
	std::clock_t	t1 = std::clock();
	double vecUs = static_cast<double>(t1 - t0) * 1000000.0 / CLOCKS_PER_SEC;

	std::clock_t	t2 = std::clock();
	_sortDeque(_deq);
	std::clock_t	t3 = std::clock();
	double deqUs = static_cast<double>(t3 - t2) * 1000000.0 / CLOCKS_PER_SEC;

	printSequenceVec("After: ", _vec);

	std::cout << std::fixed << std::setprecision(5);
	std::cout << "Time to process a range of " << _vec.size()
	          << " elements with std::vector : " << vecUs << " us" << std::endl;
	std::cout << "Time to process a range of " << _deq.size()
	          << " elements with std::deque  : " << deqUs << " us" << std::endl;
}
