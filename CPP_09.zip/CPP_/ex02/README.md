# Exercise 02 — PmergeMe 🧬
> Goal: sort a sequence of positive integers (given on the command line) using the **Ford-Johnson merge-insertion algorithm**, using **two different containers** and reporting how fast each one was.
```
$ ./PmergeMe 3 5 9 7 4
Before: 3 5 9 7 4
After:  3 4 5 7 9
Time to process a range of 5 elements with std::vector : 0.00012 us
Time to process a range of 5 elements with std::deque  : 0.00017 us
```
## 1. Vocabulary cheat sheet
| Word | Meaning (in beginner language) |
|---|---|
| **Sorting** | Rearranging items so they grow smallest → largest. |
| **Comparison** | One `a < b` check. The "cost" of comparison-based sorts. |
| **Binary search** | Halve the search range each step. Finds a position in a sorted array in ≈ log₂(n) checks. |
| **Pair** | Two elements bundled together so we can remember who was "with whom". |
| **Main chain** | The growing sorted list during the algorithm. |
| **Pend / Pending** | Elements waiting to be inserted into the main chain. |
| **Straggler** | The odd element when the input size is odd. |
| **Jacobsthal numbers** | A special sequence that tells us the *best order* to insert pending elements. |
## 2. Why Ford-Johnson?
The Ford-Johnson algorithm (a.k.a. **merge-insertion sort**) uses the **smallest known number of comparisons** to sort `n` items in the worst case for small `n`. It is mostly a theoretical marvel — real-world sorts like `std::sort` use different strategies — but understanding it teaches you:
* How clever pairing reduces the sorting problem.
* Why **binary insertion** is better than linear insertion.
* What the **Jacobsthal sequence** does and why.
## 3. The algorithm in 7 pictures
Example input: `[8, 2, 5, 1, 9, 3]`
### Step 1 — Pair up
Group elements in twos. Inside each pair, put the larger on the left.
```
 (8,2)   (5,1)   (9,3)
  ^ ^     ^ ^     ^ ^
 big sm  big sm  big sm
```
### Step 2 — Sort the pairs by their bigger value
(Only the `big` values matter here — the smaller ones follow their partner.)
```
 (5,1)   (8,2)   (9,3)        ← sorted by big: 5 < 8 < 9
```
### Step 3 — Build the "main chain"
Main chain = the sequence of all `big` values **in their new sorted order**:
```
 main = [ 5,  8,  9 ]
```
### Step 4 — The first small is *free*
The smallest `big` (5) sits in front of the main chain. Its partner (1) is guaranteed smaller than everything in `main`, so we **prepend** it for free:
```
 main = [ 1,  5,  8,  9 ]
 pend = [     2,      3 ]   ← the other smalls, in the same order as their big
```
### Step 5 — Insert pend values using **binary search**
We don't scan linearly; we binary-search the position.
Insert 3 first (we'll explain the order in Step 6):
```
 main = [ 1, 3, 5, 8, 9 ]
```
Then 2:
```
 main = [ 1, 2, 3, 5, 8, 9 ]
```
### Step 6 — Why Jacobsthal order?
For each pend element, we already know it is **smaller than** its partner in `main`. That lets us bound the search range. But if we insert pend elements in the **wrong** order, we waste binary-search capacity.
Jacobsthal numbers: `1, 3, 5, 11, 21, 43, 85, ...`
They tell us to insert pend elements in groups: first insert `b3`, then `b2`; then `b5`, then `b4`; then `b11`, `b10`, …, `b6`; and so on. This shape means **every binary search fits in exactly ⌈log₂⌉ comparisons** — no waste.
### Step 7 — Handle the straggler
If `n` was odd, one element never got paired. At the very end, just binary-insert it into `main`.
## 4. Mermaid flowchart
```mermaid
flowchart TD
    A[Input sequence] --> B{size < 2 ?}
    B -- yes --> Z[done]
    B -- no --> C{size is odd ?}
    C -- yes --> D[save last as straggler]
    C -- no --> E[no straggler]
    D --> F[form pairs larger,smaller]
    E --> F
    F --> G[binary-insertion sort of pairs by larger]
    G --> H[main = smaller of first pair + all larger values]
    H --> I[pend = smaller of pairs 2..n]
    I --> J[insert pend into main in Jacobsthal order using binary search]
    J --> K{straggler?}
    K -- yes --> L[binary-insert straggler]
    K -- no --> M[skip]
    L --> Z
    M --> Z
```
## 5. `std::vector` vs `std::deque` — what's the difference?
Both are containers of `int`, both support `operator[]`, both can `push_back`. The **difference is the memory layout**:
```
std::vector<int>   (one big contiguous block on the heap)

  ┌─┬─┬─┬─┬─┬─┬─┬─┬─┬─┬─┬─┬─┬─┬─┬─┐
  │3│1│4│1│5│9│2│6│5│3│5│8│9│7│9│ │  ← capacity may exceed size
  └─┴─┴─┴─┴─┴─┴─┴─┴─┴─┴─┴─┴─┴─┴─┴─┘
```
```
std::deque<int>    (a table of fixed-size "chunks" on the heap)

  chunk table (heap)
  ┌─────┬─────┬─────┬─────┐
  │  *  │  *  │  *  │  *  │
  └──┬──┴──┬──┴──┬──┴──┬──┘
     │     │     │     │
     ▼     ▼     ▼     ▼
   [####] [####] [####] [####]   ← each chunk holds a few ints
```
### Consequences
| Aspect | `std::vector` | `std::deque` |
|---|---|---|
| Random access `v[i]` | extremely fast (single pointer add) | fast but one extra indirection |
| `push_back` | amortised O(1), may reallocate **the whole block** | O(1), never moves existing elements |
| `push_front` | O(n) — not supported directly | O(1) — real selling point |
| `insert(middle)` | O(n) — shifts all elements after | O(n) — also shifts, but cheaper for inserts near either end |
| Memory locality | Best (CPU cache loves contiguous data) | Still good but less predictable |
That's why, for Ford-Johnson's many middle-inserts, you often see `std::vector` slightly faster than `std::deque` on modern CPUs.
## 6. Memory picture during a sort
```
STACK (in main)                    HEAP
-----------------                  ---------------------------------
PmergeMe pm;                       ┌────────────────────────────┐
 ├─ std::vector<int> _vec  ──────► │  one contiguous int block  │
 └─ std::deque<int>  _deq  ──────► │  chunk-table + chunks      │
                                   └────────────────────────────┘

during _sortVector we create temporaries:
  pairs  (vector of std::pair<int,int>)        ► heap
  main   (vector<int>, final sorted)           ► heap
  pend   (vector<int>)                         ► heap
  done   (vector<bool>, one bit per pend)      ► heap
  jac    (vector<size_t>, ~log n entries)      ► heap
```
All of these are local variables with automatic storage duration — when the function returns, their destructors fire and the heap buffers are freed. **Zero manual `new` / `delete`**, hence zero leaks.
### Lifetime timeline
```
time ─►
main starts
 │
 │ PmergeMe pm;               ← _vec, _deq created (empty, tiny)
 │ pm.parse(argc, argv);      ← both containers grow (heap allocations)
 │ pm.run()
 │    ├── _sortVector(_vec)   ← local vectors allocated, freed at return
 │    ├── _sortDeque(_deq)    ← local deques  allocated, freed at return
 │    └── print times
 │
 │ (pm goes out of scope)     ← _vec and _deq destructors free their heap
main ends
```
## 7. Build & run
```bash
make
./PmergeMe 3 5 9 7 4
./PmergeMe `shuf -i 1-100000 -n 3000 | tr '\n' ' '`    # 3000-element stress test
./PmergeMe "-1" "2"                                      # -> Error
./PmergeMe "hello"                                       # -> Error
```
Expected shape of output for the random test:
```
Before: 141 79 526 321 ...
After:  79 141 321 526 ...
Time to process a range of 3000 elements with std::vector : 45.12345 us
Time to process a range of 3000 elements with std::deque  : 67.89012 us
```
## 8. Input validation
The `parse` function rejects with `"Error"` if:
* no numbers are given
* any argument contains non-digit characters (including `-`, spaces, letters)
* any argument overflows `int`
Duplicate handling is left to the implementer's discretion (the subject says so). Our version accepts duplicates; they simply appear multiple times in the sorted output.
## 9. Container reservation
This exercise uses **both** `std::vector` and `std::deque` — which is fine because the subject explicitly allows two different containers for this exercise, and neither of them was used by name in ex00 (`std::map`) or ex01 (`std::stack`).
