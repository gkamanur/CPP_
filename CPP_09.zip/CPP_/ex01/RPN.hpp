#ifndef RPN_HPP
# define RPN_HPP

# include <string>
# include <stack>

/*
 * RPN (Reverse Polish Notation) evaluator
 * ----------------------------------------
 * Why std::stack?
 *   RPN is *defined* in terms of a stack:
 *     - push every number
 *     - when you see an operator, pop the two top values, apply,
 *       and push the result
 *   std::stack is a container-adaptor; by default it wraps std::deque,
 *   but for us the abstraction is all we need.
 */
class RPN
{
	private:
		std::stack<int> _stack;

		bool	_isOperator(char c) const;
		int		_applyOp(int a, int b, char op) const;

	public:
		// Orthodox Canonical Form
		RPN();
		RPN(const RPN& other);
		RPN& operator=(const RPN& other);
		~RPN();

		int		evaluate(const std::string& expression);
};

#endif
