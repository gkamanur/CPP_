#include "RPN.hpp"

#include <sstream>
#include <stdexcept>
#include <cctype>

/* ---------- Orthodox Canonical Form ---------- */

RPN::RPN() {}

RPN::RPN(const RPN& other) : _stack(other._stack) {}

RPN& RPN::operator=(const RPN& other)
{
	if (this != &other)
		_stack = other._stack;
	return *this;
}

RPN::~RPN() {}

/* ---------- Private helpers ---------- */

bool	RPN::_isOperator(char c) const
{
	return c == '+' || c == '-' || c == '*' || c == '/';
}

int		RPN::_applyOp(int a, int b, char op) const
{
	switch (op)
	{
		case '+': return a + b;
		case '-': return a - b;
		case '*': return a * b;
		case '/':
			if (b == 0)
				throw std::runtime_error("Error");
			return a / b;
	}
	throw std::runtime_error("Error");
}

/* ---------- Public API ---------- */

int	RPN::evaluate(const std::string& expression)
{
	// Clear any state from a previous call.
	while (!_stack.empty())
		_stack.pop();

	std::istringstream iss(expression);
	std::string token;
	while (iss >> token)
	{
		if (token.size() == 1 && _isOperator(token[0]))
		{
			if (_stack.size() < 2)
				throw std::runtime_error("Error");
			int b = _stack.top(); _stack.pop();
			int a = _stack.top(); _stack.pop();
			_stack.push(_applyOp(a, b, token[0]));
		}
		else if (token.size() == 1
			&& std::isdigit(static_cast<unsigned char>(token[0])))
		{
			// Subject: numbers are strictly less than 10 (single digit).
			_stack.push(token[0] - '0');
		}
		else
		{
			throw std::runtime_error("Error");
		}
	}

	if (_stack.size() != 1)
		throw std::runtime_error("Error");
	return _stack.top();
}
