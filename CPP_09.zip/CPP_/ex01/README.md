# Exercise 01 — Reverse Polish Notation 🧮
> Goal: given an arithmetic expression in **Reverse Polish Notation** on the command line, compute and print the result.
```
$ ./RPN "8 9 * 9 - 9 - 9 - 4 - 1 +"
42
```
## 1. What is RPN (and why stacks are amazing)
Normal "infix" math: `3 + 4` — operator **between** the operands.
Reverse Polish: `3 4 +` — operator **after** the operands.
Why? Because you never need parentheses and you never need operator-precedence rules — the order of tokens **is** the order of computation. This makes RPN trivially evaluable with a single data structure: a **stack**.
### The single rule of RPN evaluation
```
read tokens one by one:
    if the token is a number  -> push it
    if the token is an operator:
        b = pop();  a = pop();
        push(a OP b);
at the end: the only remaining value is the result
```
## 2. Why `std::stack`?
`std::stack` is a **container adaptor** that exposes only three operations:
* `push(x)` — put on top
* `pop()` — remove the top
* `top()` — look at the top
That is **exactly** the RPN vocabulary. Using a more powerful container (like `vector`) would expose operations we must not use (random access), so `std::stack` communicates intent perfectly.
Internally, `std::stack<int>` uses a `std::deque<int>` by default — you don't need to care.
## 3. Step-by-step trace
Input: `"1 2 * 2 / 2 * 2 4 - +"` → expected result **0**
```
token   | action              | stack (bottom -> top)
--------|---------------------|-----------------------
  1     | push 1              | [1]
  2     | push 2              | [1, 2]
  *     | pop 2,1 -> push 2   | [2]
  2     | push 2              | [2, 2]
  /     | pop 2,2 -> push 1   | [1]
  2     | push 2              | [1, 2]
  *     | pop 2,1 -> push 2   | [2]
  2     | push 2              | [2, 2]
  4     | push 4              | [2, 2, 4]
  -     | pop 4,2 -> push -2  | [2, -2]
  +     | pop -2,2 -> push 0  | [0]
```
Final stack size is 1 → print `0`.
### ⚠️ Careful with operand order
When an operator is encountered we do:
```cpp
b = pop();    // the most recently pushed operand
a = pop();    // the older one
push(a OP b); // NOT (b OP a) !
```
So `"5 3 -"` means `5 - 3 = 2`, **not** `3 - 5`.
## 4. Program flow
```mermaid
flowchart TD
    S([./RPN "tokens"]) --> A{argc == 2 ?}
    A -- no --> X[print Error] --> Z([exit 1])
    A -- yes --> B[tokenize with istringstream]
    B --> C{next token ?}
    C -- digit --> D[stack.push digit]
    D --> C
    C -- operator --> E{size >= 2 ?}
    E -- no --> X
    E -- yes --> F[b = top, pop; a = top, pop]
    F --> G{op}
    G -- / and b==0 --> X
    G --> H[push a OP b]
    H --> C
    C -- other char --> X
    C -- end of input --> I{size == 1 ?}
    I -- no --> X
    I -- yes --> J[print top] --> Z([exit 0])
```
## 5. Memory behavior
```
STACK (CPU stack, automatic storage)         HEAP
-------------------------------------        ------------------------------
main()
 └─ RPN rpn;   (a few bytes: ptr/size)  ───►  ┌─────────────────────────┐
     └─ std::stack<int> _stack                │  deque's internal chunks │
        (wraps std::deque<int>)               │  holding pushed ints     │
                                              └─────────────────────────┘
```
### Two "stacks" — don't get confused
When we say "stack" in this exercise we mean **two different things**:
1. **The CPU call stack** — a region of memory where local variables and function call frames live. `main`'s `RPN rpn;` lives here.
2. **`std::stack<int>`** — a C++ data-structure object that happens to also be called a stack. Its numeric storage actually lives on the **heap**.
```
time ─►
main starts ─► RPN rpn constructed ─► evaluate() called
   │                                       │
   │                              while (iss >> token) …
   │                              push/pop → heap nodes are added/removed
   │                                       │
   │             evaluate() returns, result printed
   │             rpn destructor runs ─► underlying deque frees its buffers
main ends
```
* No `new`, no `delete` → no manual memory management, no leaks.
* If the expression is invalid we throw a `std::runtime_error`. Stack unwinding destroys `rpn`, which destroys the deque, which frees its buffers — this is **RAII**, C++'s answer to "I forgot to free memory".
## 6. Build & run
```bash
make
./RPN "8 9 * 9 - 9 - 9 - 4 - 1 +"    # 42
./RPN "7 7 * 7 -"                    # 42
./RPN "1 2 * 2 / 2 * 2 4 - +"        # 0
./RPN "(1 + 1)"                      # Error
./RPN "1 0 /"                        # Error (division by zero)
```
## 7. Error cases we catch
| Case | How we detect it |
|---|---|
| `argc != 2` | `main` guard |
| token is not a digit and not `+-*/` | fallthrough `else` in `evaluate` |
| number ≥ 10 (multi-digit) | `token.size() != 1` |
| operator without 2 operands | `_stack.size() < 2` |
| division by 0 | check in `_applyOp` |
| leftover stack ( e.g. `"1 2 3 +"`) | `_stack.size() != 1` at end |
## 8. Container reservation
`std::stack` (the adaptor we used directly) is **reserved to this exercise** and must not be reused in ex02. We did not manipulate an underlying container by name here.
