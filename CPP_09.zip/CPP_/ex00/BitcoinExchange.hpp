#ifndef BITCOINEXCHANGE_HPP
# define BITCOINEXCHANGE_HPP

# include <string>
# include <map>

/*
 * BitcoinExchange
 * ----------------
 * - Loads a CSV "date,price" into an ordered std::map.
 * - For each line "date | value" in an input file, finds the closest
 *   (lower or equal) date in the database and prints value * rate.
 *
 * Why std::map?
 *   - Keys are automatically kept sorted (Red-Black tree).
 *   - lower_bound gives O(log n) lookup of the "closest lower" date.
 */
class BitcoinExchange
{
	private:
		std::map<std::string, float> _database;

		// Helpers (kept private - only useful to this class)
		bool		_isValidDate(const std::string& date) const;
		bool		_isValidValue(const std::string& value, float& out) const;
		std::string	_trim(const std::string& s) const;

	public:
		// Orthodox Canonical Form (required by the subject)
		BitcoinExchange();
		BitcoinExchange(const BitcoinExchange& other);
		BitcoinExchange& operator=(const BitcoinExchange& other);
		~BitcoinExchange();

		// Public API
		void	loadDatabase(const std::string& filename);
		void	processInput(const std::string& filename);
		float	getRate(const std::string& date) const;
};

#endif
