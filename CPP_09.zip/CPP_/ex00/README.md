# Exercise 00 — Bitcoin Exchange 💰
> Goal: read a historical price database (`data.csv`) and, for every line in a user-supplied input file (`date | value`), print `value × exchange_rate` for that date.
## 1. What you will learn
| Concept | Why it matters |
|---|---|
| `std::map` | An **ordered** associative container (keys stay sorted automatically). |
| `lower_bound` | How to find the **closest key** in O(log n) without writing your own search. |
| File I/O (`std::ifstream`) | Reading line-by-line in the C++ way. |
| String parsing (`substr`, `find`) | Splitting `"date | value"` without `sscanf`. |
| Orthodox Canonical Form | The 4 special member functions every C++98 class must define. |
| Exceptions | Reporting errors cleanly without `return -1` spaghetti. |
## 2. Why `std::map` is the perfect tool here
A `std::map<std::string, float>` is internally a **Red–Black tree** — a self-balancing binary search tree.
```
                           ┌───────────────────┐
                           │   2015-01-14      │
                           │        172.15     │
                           └─────────┬─────────┘
                                     │
                 ┌───────────────────┴───────────────────┐
        ┌────────┴────────┐                     ┌────────┴────────┐
        │   2011-06-08    │                     │   2018-06-15    │
        │       29.60     │                     │      6502.02    │
        └───────┬─────────┘                     └────────┬────────┘
                │                                        │
         ┌──────┴──────┐                          ┌──────┴──────┐
   2011-01-03      2013-11-29                2017-01-01     2021-04-14
      0.3            1137.39                    997.69       63314.01
```
Key properties used in this exercise:
1. Keys are always **sorted** (lexicographic order on dates `YYYY-MM-DD` happens to match chronological order — lucky!).
2. `insert` / `lookup` are **O(log n)**.
3. `lower_bound(k)` returns an iterator to the first key ≥ `k`. If our exact date is missing we just step back once (`--it`) to get the closest **earlier** date — exactly what the subject asks for.
## 3. Program flow (high level)
```mermaid
flowchart TD
    A([./btc input.txt]) --> B{argc == 2 ?}
    B -- no --> E1[Error: could not open file.] --> Z([exit 1])
    B -- yes --> C[Load data.csv into std::map]
    C --> D{opened ok?}
    D -- no --> E2[throw runtime_error] --> Z
    D -- yes --> F[Read input file line by line]
    F --> G{split 'date | value'}
    G -- bad format --> H1[Error: bad input] --> F
    G -- ok --> I{date valid?}
    I -- no --> H1
    I -- yes --> J{value valid?}
    J -- negative --> H2[Error: not a positive number.] --> F
    J -- too big --> H3[Error: too large a number.] --> F
    J -- ok --> K[rate = map.lower_bound then step back]
    K --> L[print date => value = value*rate]
    L --> F
    F -- EOF --> Z([exit 0])
```
## 4. Memory picture
```
  STACK                              HEAP
  ------------                       ---------------------------
  main()                             ┌─────────────────────────┐
   └─ BitcoinExchange btc ──────────►│  std::map internal nodes │
      └─ _database (8 bytes ptr +    │  (key:string, val:float) │
         size + comparator)          │  allocated by map's      │
                                     │  allocator as we insert  │
                                     └─────────────────────────┘
```
* The `BitcoinExchange` object itself lives on the **stack** (local variable in `main`).
* The `std::map` contains a small header on the stack, but **every tree node is allocated on the heap** by the map's allocator when you call `insert` / `operator[]`.
* Each `std::string` key also owns a heap buffer (for strings longer than the small-string-optimisation buffer).
* We never call `new` or `delete` ourselves → **zero chance of leaks** as long as the map goes out of scope normally. When `main` returns, `btc`'s destructor is called, which destroys the map, which frees every node. Clean.
### Lifetime timeline
```
   time ─►
   main starts                    main ends
   │                                   │
   │ create btc ─┐       use btc       │
   │             ├─── loadDatabase ────┤
   │             │  (map grows on heap)│
   │             └── processInput ─────┘
   │                                   │
   │                      btc destructor runs → map frees nodes
```
## 5. Build & run
```bash
make          # produces ./btc
./btc input.txt
make fclean   # remove binary + objects
```
Expected output (with the provided `data.csv` + `input.txt`):
```
2011-01-03 => 3 = 0.9
2011-01-03 => 2 = 0.6
2011-01-03 => 1 = 0.3
2011-01-03 => 1.2 = 0.36
2011-01-09 => 1 = 0.32
Error: not a positive number.
Error: bad input => 2001-42-42
2012-01-11 => 1 = 7.1
Error: too large a number.
```
## 6. Things worth noticing in the code
* `_database.lower_bound(date)` — **do not** use `find`: it only matches exact keys.
* Date validation checks month/day ranges **and** leap years.
* `strtod` + endptr check is how we reject inputs like `"1.2abc"` or `"2147483648"` without `scanf`.
* The Orthodox Canonical Form (default ctor, copy ctor, `operator=`, dtor) is present even though the map manages its own memory — the subject mandates it.
## 7. Container reservation
`std::map` is **used here and therefore forbidden in ex01 and ex02**.
