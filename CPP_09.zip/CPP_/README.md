# C++ Module 09 — STL 📚
This repository contains the three exercises of the 42 **C++ Module 09** project. The theme of the module is the **Standard Template Library**: after eight modules of hand-rolled linked lists and custom templates, we finally get to use containers and algorithms from the standard library.
## Repository layout
```
CPP_/
├── ex00/   Bitcoin Exchange   — uses std::map
├── ex01/   Reverse Polish     — uses std::stack
├── ex02/   PmergeMe           — uses std::vector AND std::deque
├── cpp09.pdf                   (the subject)
└── README.md                   (this file)
```
Each exercise folder is **self-contained** and has its own `Makefile` + `README.md`.
## Container usage rule
The subject enforces a strict rule:
> *"Once a container is used you cannot use it for the rest of the module."*
So we chose the containers carefully so nothing overlaps:
| Exercise | Container(s) used | Why |
|---|---|---|
| `ex00` | `std::map<std::string, float>` | Ordered key→value lookup by date |
| `ex01` | `std::stack<int>` | RPN is defined in terms of a stack |
| `ex02` | `std::vector<int>` + `std::deque<int>` | Two containers required; compare their speed |
## What you learn, module-wide
```mermaid
flowchart LR
    A[ex00 map] --> B[ex01 stack] --> C[ex02 vector + deque]
    A -. ordered lookup .-> X[(STL idioms)]
    B -. LIFO + adaptors .-> X
    C -. algorithms + benchmarking .-> X
```
* **Container choice matters** — pick the structure whose API matches the problem statement.
* **Orthodox Canonical Form** — C++98 classes define default ctor, copy ctor, `operator=`, dtor.
* **RAII** — the destructor cleans up; no manual `new`/`delete`.
* **STL iterators & algorithms** — `lower_bound`, `upper_bound`, and friends.
* **Performance awareness** — exercise 02 actually measures microseconds.
## Build & run everything
```bash
# Build each exercise independently
make -C ex00   &&  ./ex00/btc        ex00/input.txt
make -C ex01   &&  ./ex01/RPN        "8 9 * 9 - 9 - 9 - 4 - 1 +"
make -C ex02   &&  ./ex02/PmergeMe   3 5 9 7 4
```
### One-shot build for the whole module (optional)
```bash
for d in ex00 ex01 ex02; do make -C $d || exit 1; done
```
### Cleaning up
```bash
for d in ex00 ex01 ex02; do make -C $d fclean; done
```
## Compile flags
Every Makefile uses: `c++ -Wall -Wextra -Werror -std=c++98`.
No warnings, no `using namespace`, no `friend`, no `printf`, no `*alloc`, no `free`.
## Reading order for beginners
1. `ex00/README.md` — easiest; learn `std::map` + file I/O.
2. `ex01/README.md` — learn the stack idiom by evaluating RPN.
3. `ex02/README.md` — level up: pairing, binary search, Jacobsthal numbers, benchmarking.
Each README contains:
* A short "what you will learn" table.
* Flowcharts (Mermaid + ASCII) for the logic.
* A **memory picture** showing what lives on the stack vs the heap.
* A lifetime timeline of the main object.
* Build & run examples.
Good luck and may the bits be with you ✨
